from django.apps import AppConfig


class CalenderSharingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'calender_sharing_app'
